from app.utils.arabic_normalizer import normalize_arabic

def test_normalizer_diacritics_and_alef_variants():
    assert normalize_arabic('أَحْمَد') == 'احمد'
