from pathlib import Path
from app.storage.database import Database

def test_insert_and_search(tmp_path: Path):
    db = Database(tmp_path / 't.db')
    db.insert_record(
        full_name='أحمد علي',
        normalized_name='احمد علي',
        address='القاهرة',
        national_id='29801011234567',
        birth_date='1998-01-01',
        age=26,
        image_path='/tmp/card.jpg',
    )
    rows = db.search_by_name('أحمد')
    assert len(rows) == 1
