from app.utils.age_calculator import calculate_age

def test_age_returns_int_or_none():
    age = calculate_age('2000-01-01')
    assert age is None or isinstance(age, int)
